//
//  ViewController.swift
//  PianoTilesSingleViewApp
//
//  Created by Tyra Kuan on 19/9/18.
//  Copyright © 2018 Tyra Kuan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Row1_1: UIButton!
    @IBOutlet weak var Row1_2: UIButton!
    @IBOutlet weak var Row1_3: UIButton!
    @IBOutlet weak var Row1_4: UIButton!
    @IBOutlet weak var Row2_1: UIButton!
    @IBOutlet weak var Row2_2: UIButton!
    @IBOutlet weak var Row2_3: UIButton!
    @IBOutlet weak var Row2_4: UIButton!
    @IBOutlet weak var Row3_1: UIButton!
    @IBOutlet weak var Row3_2: UIButton!
    @IBOutlet weak var Row3_3: UIButton!
    @IBOutlet weak var Row3_4: UIButton!
    @IBOutlet weak var Row4_1: UIButton!
    @IBOutlet weak var Row4_2: UIButton!
    @IBOutlet weak var Row4_3: UIButton!
    @IBOutlet weak var Row4_4: UIButton!
    
    var currentTiles = [0,3,1,2]
    
    @IBAction func Change(_ sender: Any) {
        Row1_1.backgroundColor = UIColor.white
        Row1_2.backgroundColor = UIColor.white
        Row1_3.backgroundColor = UIColor.white
        Row1_4.backgroundColor = UIColor.white
        Row2_1.backgroundColor = UIColor.white
        Row2_2.backgroundColor = UIColor.white
        Row2_3.backgroundColor = UIColor.white
        Row2_4.backgroundColor = UIColor.white
        Row3_1.backgroundColor = UIColor.white
        Row3_2.backgroundColor = UIColor.white
        Row3_3.backgroundColor = UIColor.white
        Row3_4.backgroundColor = UIColor.white
        Row4_1.backgroundColor = UIColor.white
        Row4_2.backgroundColor = UIColor.white
        Row4_3.backgroundColor = UIColor.white
        Row4_4.backgroundColor = UIColor.white
        
        let a = Int(arc4random_uniform(4))
        currentTiles.insert(a, at: 0)
        if a == 1{
            Row1_1.backgroundColor = UIColor.black
        } else if a == 2{
            Row1_2.backgroundColor = UIColor.black
        } else if a == 3{
            Row1_3.backgroundColor = UIColor.black
        } else  {
            Row1_4.backgroundColor = UIColor.black
        }
        if currentTiles[1] == 1{
            Row2_1.backgroundColor = UIColor.black
        } else if currentTiles[1] == 2{
            Row2_2.backgroundColor = UIColor.black
        } else if currentTiles[1] == 3{
            Row2_3.backgroundColor = UIColor.black
        } else  {
            Row2_4.backgroundColor = UIColor.black
        }
        if currentTiles[2] == 1{
            Row3_1.backgroundColor = UIColor.black
        } else if currentTiles[2] == 2{
            Row3_2.backgroundColor = UIColor.black
        } else if currentTiles[2] == 3{
            Row3_3.backgroundColor = UIColor.black
        } else  {
            Row3_4.backgroundColor = UIColor.black
        }
        if currentTiles[3] == 1{
            Row4_1.backgroundColor = UIColor.black
        } else if currentTiles[3] == 2{
            Row4_2.backgroundColor = UIColor.black
        } else if currentTiles[3] == 3{
            Row4_3.backgroundColor = UIColor.black
        } else {
            Row4_4.backgroundColor = UIColor.black
        }
        
        print(a)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        Row1_1.layer.borderWidth = 1
        Row1_2.layer.borderWidth = 1
        Row1_3.layer.borderWidth = 1
        Row1_4.layer.borderWidth = 1
        Row2_1.layer.borderWidth = 1
        Row2_2.layer.borderWidth = 1
        Row2_3.layer.borderWidth = 1
        Row2_4.layer.borderWidth = 1
        Row3_1.layer.borderWidth = 1
        Row3_2.layer.borderWidth = 1
        Row3_3.layer.borderWidth = 1
        Row3_4.layer.borderWidth = 1
        Row4_1.layer.borderWidth = 1
        Row4_2.layer.borderWidth = 1
        Row4_3.layer.borderWidth = 1
        Row4_4.layer.borderWidth = 1
       /* for i in 1...4 {
            for o in 1...4{
                let cell = "Row\(i)_\(o)" as? UIButton
                print(cell)
                cell?.layer.borderColor = UIColor.black as! CGColor
                cell?.layer.borderWidth = 2
            }
        }*/
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

