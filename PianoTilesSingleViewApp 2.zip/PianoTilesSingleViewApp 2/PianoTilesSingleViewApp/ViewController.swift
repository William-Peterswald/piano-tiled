//
//  ViewController.swift
//  PianoTilesSingleViewApp
//
//  Created by Tyra Kuan on 19/9/18.
//  Copyright © 2018 Tyra Kuan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Row1_1: UIButton!
    @IBOutlet weak var Row1_2: UIButton!
    @IBOutlet weak var Row1_3: UIButton!
    @IBOutlet weak var Row1_4: UIButton!
    @IBOutlet weak var Row2_1: UIButton!
    @IBOutlet weak var Row2_2: UIButton!
    @IBOutlet weak var Row2_3: UIButton!
    @IBOutlet weak var Row2_4: UIButton!
    @IBOutlet weak var Row3_1: UIButton!
    @IBOutlet weak var Row3_2: UIButton!
    @IBOutlet weak var Row3_3: UIButton!
    @IBOutlet weak var Row3_4: UIButton!
    @IBOutlet weak var Row4_1: UIButton!
    @IBOutlet weak var Row4_2: UIButton!
    @IBOutlet weak var Row4_3: UIButton!
    @IBOutlet weak var Row4_4: UIButton!
    
    
    @IBAction func Change(_ sender: Any) {
        for o in 1...4{
            let cell = "Row1_\(o)" as? UIButton
            cell?.backgroundColor = UIColor.white
        }
        let a = Int(arc4random_uniform(4))
        
        if a == 1{
            Row1_1.backgroundColor = UIColor.black
        } else if a == 2{
            Row1_2.backgroundColor = UIColor.black
        } else if a == 3{
            Row1_3.backgroundColor = UIColor.black
        } else  {
            Row1_4.backgroundColor = UIColor.black
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        for i in 1...4 {
            for o in 1...4{
                let cell = "Row\(i)_\(o)" as? UIButton
                cell!.layer.borderColor = UIColor.black as! CGColor
                cell!.layer.borderWidth = 2
            }
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

