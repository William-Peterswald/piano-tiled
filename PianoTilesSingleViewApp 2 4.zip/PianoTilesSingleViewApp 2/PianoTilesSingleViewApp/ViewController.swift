//
//  ViewController.swift
//  PianoTilesSingleViewApp
//
//  Created by Tyra Kuan on 19/9/18.
//  Copyright © 2018 Tyra Kuan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var started = true
    
    @IBOutlet weak var Row1_1: UIButton!
    @IBOutlet weak var Row1_2: UIButton!
    @IBOutlet weak var Row1_3: UIButton!
    @IBOutlet weak var Row1_4: UIButton!
    @IBOutlet weak var Row2_1: UIButton!
    @IBOutlet weak var Row2_2: UIButton!
    @IBOutlet weak var Row2_3: UIButton!
    @IBOutlet weak var Row2_4: UIButton!
    @IBOutlet weak var Row3_1: UIButton!
    @IBOutlet weak var Row3_2: UIButton!
    @IBOutlet weak var Row3_3: UIButton!
    @IBOutlet weak var Row3_4: UIButton!
    @IBOutlet weak var Row4_1: UIButton!
    @IBOutlet weak var Row4_2: UIButton!
    @IBOutlet weak var Row4_3: UIButton!
    @IBOutlet weak var Row4_4: UIButton!
    
    
    var currentTiles = [Int(arc4random_uniform(4)),Int(arc4random_uniform(4)),Int(arc4random_uniform(4)),Int(arc4random_uniform(4))]
    var buttons = [UIButton]()
    
    UIViewController!.performSegue(GameLost) = false
    @IBAction func Change(_ sender: Any) {
        let cell = sender as? UIButton
        var colour = cell!.backgroundColor!
        print((cell?.backgroundColor!)!)

        if colour == UIColor.black || started {
          for i in 0...15 {
              buttons[i].backgroundColor = UIColor.white
          }

            started = false
        let a = Int(arc4random_uniform(4))
        currentTiles.insert(a, at: 0)
        if a == 1{
            Row1_1.backgroundColor = UIColor.black
        } else if a == 2{
            Row1_2.backgroundColor = UIColor.black
        } else if a == 3{
            Row1_3.backgroundColor = UIColor.black
        } else  {
            Row1_4.backgroundColor = UIColor.black
        }
        if currentTiles[1] == 1{
            Row2_1.backgroundColor = UIColor.black
        } else if currentTiles[1] == 2{
            Row2_2.backgroundColor = UIColor.black
        } else if currentTiles[1] == 3{
            Row2_3.backgroundColor = UIColor.black
        } else  {
            Row2_4.backgroundColor = UIColor.black
        }
        if currentTiles[2] == 1{
            Row3_1.backgroundColor = UIColor.black
        } else if currentTiles[2] == 2{
            Row3_2.backgroundColor = UIColor.black
        } else if currentTiles[2] == 3{
            Row3_3.backgroundColor = UIColor.black
        } else  {
            Row3_4.backgroundColor = UIColor.black
        }
        if currentTiles[3] == 1{
            Row4_1.backgroundColor = UIColor.gray
        } else if currentTiles[3] == 2{
            Row4_2.backgroundColor = UIColor.gray
        } else if currentTiles[3] == 3{
            Row4_3.backgroundColor = UIColor.gray
        } else {
            Row4_4.backgroundColor = UIColor.gray
        }
        
        print(a)
        }
        
        else {
            cell?.backgroundColor = UIColor.red
            lose()
            performSegue(withIdentifier: "GameLost", sender: nil)
        }
    }
    
    func lose(){
    }
    
    override func viewDidLoad() {
        buttons = [Row1_1,Row1_2,Row1_3,Row1_4,Row2_1,Row2_2,Row2_3,Row2_4,Row3_1,Row3_2,Row3_3,Row3_4,Row4_1,Row4_2,Row4_3,Row4_4]
        
        super.viewDidLoad()
        
        for i in 0...15 {
            buttons[i].layer.borderWidth = 1
        }
        
        Change(Row3_1!)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

